﻿using System;

namespace market_otomasyonu
{
    partial class sifremi_unuttum
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grp_soruyönetimi = new System.Windows.Forms.GroupBox();
            this.grp_sifredegistir = new System.Windows.Forms.GroupBox();
            this.btn_sifredegistir = new System.Windows.Forms.Button();
            this.txt_yenisifretekrar = new System.Windows.Forms.TextBox();
            this.txt_yenisifre = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_sorgula = new System.Windows.Forms.Button();
            this.cmb_guvenliksorusu = new System.Windows.Forms.ComboBox();
            this.txt_guvenlikcevabi = new System.Windows.Forms.TextBox();
            this.txt_kullaniciadi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.grp_soruyönetimi.SuspendLayout();
            this.grp_sifredegistir.SuspendLayout();
            this.SuspendLayout();
            // 
            // grp_soruyönetimi
            // 
            this.grp_soruyönetimi.Controls.Add(this.grp_sifredegistir);
            this.grp_soruyönetimi.Controls.Add(this.btn_sorgula);
            this.grp_soruyönetimi.Controls.Add(this.cmb_guvenliksorusu);
            this.grp_soruyönetimi.Controls.Add(this.txt_guvenlikcevabi);
            this.grp_soruyönetimi.Controls.Add(this.txt_kullaniciadi);
            this.grp_soruyönetimi.Controls.Add(this.label3);
            this.grp_soruyönetimi.Controls.Add(this.label2);
            this.grp_soruyönetimi.Controls.Add(this.label1);
            this.grp_soruyönetimi.Location = new System.Drawing.Point(35, 27);
            this.grp_soruyönetimi.Name = "grp_soruyönetimi";
            this.grp_soruyönetimi.Size = new System.Drawing.Size(415, 746);
            this.grp_soruyönetimi.TabIndex = 0;
            this.grp_soruyönetimi.TabStop = false;
            this.grp_soruyönetimi.Text = "Güvenlik Soru Yönetimi";
            // 
            // grp_sifredegistir
            // 
            this.grp_sifredegistir.Controls.Add(this.btn_sifredegistir);
            this.grp_sifredegistir.Controls.Add(this.txt_yenisifretekrar);
            this.grp_sifredegistir.Controls.Add(this.txt_yenisifre);
            this.grp_sifredegistir.Controls.Add(this.label5);
            this.grp_sifredegistir.Controls.Add(this.label4);
            this.grp_sifredegistir.Location = new System.Drawing.Point(25, 310);
            this.grp_sifredegistir.Name = "grp_sifredegistir";
            this.grp_sifredegistir.Size = new System.Drawing.Size(351, 403);
            this.grp_sifredegistir.TabIndex = 4;
            this.grp_sifredegistir.TabStop = false;
            this.grp_sifredegistir.Text = "Şifre Değiştir";
            this.grp_sifredegistir.Enter += new System.EventHandler(this.grp_sifredegistir_Enter);
            // 
            // btn_sifredegistir
            // 
            this.btn_sifredegistir.Location = new System.Drawing.Point(37, 258);
            this.btn_sifredegistir.Name = "btn_sifredegistir";
            this.btn_sifredegistir.Size = new System.Drawing.Size(265, 31);
            this.btn_sifredegistir.TabIndex = 2;
            this.btn_sifredegistir.Text = "Şifre Değiştir";
            this.btn_sifredegistir.UseVisualStyleBackColor = true;
            this.btn_sifredegistir.Click += new System.EventHandler(this.btn_sifredegistir_Click);
            // 
            // txt_yenisifretekrar
            // 
            this.txt_yenisifretekrar.Location = new System.Drawing.Point(140, 173);
            this.txt_yenisifretekrar.Name = "txt_yenisifretekrar";
            this.txt_yenisifretekrar.Size = new System.Drawing.Size(179, 22);
            this.txt_yenisifretekrar.TabIndex = 1;
            // 
            // txt_yenisifre
            // 
            this.txt_yenisifre.Location = new System.Drawing.Point(140, 77);
            this.txt_yenisifre.Name = "txt_yenisifre";
            this.txt_yenisifre.Size = new System.Drawing.Size(179, 22);
            this.txt_yenisifre.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(25, 173);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Yeni Şifre(tekrar):";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(25, 83);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(67, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Yeni Şifre:";
            // 
            // btn_sorgula
            // 
            this.btn_sorgula.Location = new System.Drawing.Point(25, 224);
            this.btn_sorgula.Name = "btn_sorgula";
            this.btn_sorgula.Size = new System.Drawing.Size(338, 36);
            this.btn_sorgula.TabIndex = 3;
            this.btn_sorgula.Text = "Sorgula";
            this.btn_sorgula.UseVisualStyleBackColor = true;
            this.btn_sorgula.Click += new System.EventHandler(this.btn_sorgula_Click);
            // 
            // cmb_guvenliksorusu
            // 
            this.cmb_guvenliksorusu.FormattingEnabled = true;
            this.cmb_guvenliksorusu.Location = new System.Drawing.Point(135, 125);
            this.cmb_guvenliksorusu.Name = "cmb_guvenliksorusu";
            this.cmb_guvenliksorusu.Size = new System.Drawing.Size(228, 24);
            this.cmb_guvenliksorusu.TabIndex = 2;
            // 
            // txt_guvenlikcevabi
            // 
            this.txt_guvenlikcevabi.Location = new System.Drawing.Point(135, 172);
            this.txt_guvenlikcevabi.Name = "txt_guvenlikcevabi";
            this.txt_guvenlikcevabi.Size = new System.Drawing.Size(228, 22);
            this.txt_guvenlikcevabi.TabIndex = 1;
            // 
            // txt_kullaniciadi
            // 
            this.txt_kullaniciadi.Location = new System.Drawing.Point(135, 72);
            this.txt_kullaniciadi.Name = "txt_kullaniciadi";
            this.txt_kullaniciadi.Size = new System.Drawing.Size(228, 22);
            this.txt_kullaniciadi.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(108, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Güvenlik Cevabı:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(107, 16);
            this.label2.TabIndex = 0;
            this.label2.Text = "Güvenlik Sorusu:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 75);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Kullanıcı Adı:";
            // 
            // sifremi_unuttum
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(452, 785);
            this.Controls.Add(this.grp_soruyönetimi);
            this.Name = "sifremi_unuttum";
            this.Text = "sifremi_unuttum";
            this.Load += new System.EventHandler(this.sifremi_unuttum_Load);
            this.grp_soruyönetimi.ResumeLayout(false);
            this.grp_soruyönetimi.PerformLayout();
            this.grp_sifredegistir.ResumeLayout(false);
            this.grp_sifredegistir.PerformLayout();
            this.ResumeLayout(false);

        }

        private void grp_sifredegistir_Enter(object sender, EventArgs e)
        {
            
        }

        #endregion

        private System.Windows.Forms.GroupBox grp_soruyönetimi;
        private System.Windows.Forms.Button btn_sorgula;
        private System.Windows.Forms.ComboBox cmb_guvenliksorusu;
        private System.Windows.Forms.TextBox txt_guvenlikcevabi;
        private System.Windows.Forms.TextBox txt_kullaniciadi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox grp_sifredegistir;
        private System.Windows.Forms.Button btn_sifredegistir;
        private System.Windows.Forms.TextBox txt_yenisifretekrar;
        private System.Windows.Forms.TextBox txt_yenisifre;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
    }
}