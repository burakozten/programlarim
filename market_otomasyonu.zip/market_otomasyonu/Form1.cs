﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace market_otomasyonu
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            List<kisi>kisilist=new List<kisi>();
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M7G5DB1\SQLEXPRESS;Initial Catalog=market;User ID=sa;Password=1");
            con.Open();
            SqlCommand cmd = new SqlCommand("select*from login_ekrani",con);
            SqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                kisi kisi = new kisi();
                kisi.id = int.Parse(dr["id"].ToString());
                kisi.kullaniciadi = dr["kullaniciadi"].ToString();
                kisi.sifre = dr["sifre"].ToString() ;
                kisi.guvenliksorusu = dr["guvenliksorusu"].ToString().ToLower();
                kisi.guvenlikcevabi = dr["guvenlikcevabi"].ToString().ToLower() ;
                kisi.yetki = dr["yetki"].ToString();
                kisilist.Add(kisi);

            }
            con.Close();
            var kullanici= kisilist.FirstOrDefault(k => txt_kullanici.Text == k.kullaniciadi && txt_sifre.Text == k.sifre);

            if (kullanici != null) // Null kontrolü ekledik
            {
                if (kullanici.yetki.ToLower() == "admin")
                {
                    admin admin = new admin();
                    admin.ShowDialog();
                    this.Hide();
                }
                else if (kullanici.yetki.ToLower() == "kasiyer")
                {
                    kasiyer kasiyer = new kasiyer();
                    kasiyer.ShowDialog();
                    this.Hide();
                }
                else
                {
                    MessageBox.Show("Bilinmeyen yetki.");
                }
            }
            else
            {
                MessageBox.Show("Kullanıcı adı veya şifre hatalı.");
            }


        }

        private void lbl_siftemiunuttum_Click(object sender, EventArgs e)
        {
            sifremi_unuttum sifre=new sifremi_unuttum();
            sifre.ShowDialog();
            this.Hide();
        }
    }
}
