﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Net.NetworkInformation;
using System.Windows.Forms;

namespace market_otomasyonu
{
    public partial class sifremi_unuttum : Form
    {
        List<kullanici_bilgileri> liste = new List<kullanici_bilgileri>(); // Global liste tanımı

        public sifremi_unuttum()
        {
            InitializeComponent();
        }

        private void btn_sorgula_Click(object sender, EventArgs e)
        {
            // Liste zaten dolu olmalı, ancak kontrol için gerekirse burada da listeyi doldurabilirsiniz.
            bool kontrol = liste.Any(kullanici_bilgileri =>
                txt_kullaniciadi.Text == kullanici_bilgileri.kullaniciadi && // Kullanıcı adını karşılaştır
                cmb_guvenliksorusu.Text == kullanici_bilgileri.guvenliksorusu && // Güvenlik sorusunu karşılaştır
                txt_guvenlikcevabi.Text.ToLower() == kullanici_bilgileri.guvenlikcevabi); // Güvenlik cevabını karşılaştır

            if (kontrol)
            {
                grp_sifredegistir.Enabled = true;
            }
            else
            {
                MessageBox.Show("Girdiğiniz bilgiler hatalı.");
            }
        }

        private void sifremi_unuttum_Load(object sender, EventArgs e)
        {
            grp_sifredegistir.Enabled = false;
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M7G5DB1\SQLEXPRESS;Initial Catalog=market;User ID=sa;Password=1");
            con.Open();
            SqlCommand cmd = new SqlCommand("select * from login_ekrani", con);
            SqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                kullanici_bilgileri bilgi = new kullanici_bilgileri();
                bilgi.id = int.Parse(dr["id"].ToString());
                bilgi.kullaniciadi = dr["kullaniciadi"].ToString();
                bilgi.sifre = dr["sifre"].ToString();
                bilgi.guvenliksorusu = dr["guvenliksorusu"].ToString();
                bilgi.guvenlikcevabi = dr["guvenlikcevabi"].ToString();
                liste.Add(bilgi);
            }
            con.Close();

            // ComboBox'a güvenlik sorularını ekle
            foreach (kullanici_bilgileri kullanici_Bilgileri in liste)
            {
                if (!cmb_guvenliksorusu.Items.Contains(kullanici_Bilgileri.guvenliksorusu))
                {
                    cmb_guvenliksorusu.Items.Add(kullanici_Bilgileri.guvenliksorusu);
                }
            }
        }

        private void btn_sifredegistir_Click(object sender, EventArgs e)
        {
            string yeniSifre = txt_yenisifre.Text;
            string yeniSifreTekrar = txt_yenisifretekrar.Text;

            // Şifrelerin aynı olup olmadığını kontrol et
            if (yeniSifre == yeniSifreTekrar)
            {
                // Kullanıcı adı veya ID gibi kimlik bilgilerini almak için uygun yerlerde değişken tanımlamanız gerekebilir
                string kullaniciAdi = txt_kullaniciadi.Text; // Örnek, gerçek uygulamada uygun bir yerden alınmalıdır

                // Veritabanı bağlantısı oluştur
                using (SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-M7G5DB1\SQLEXPRESS;Initial Catalog=market;User ID=sa;Password=1"))
                {
                    con.Open();

                    // SQL komutunu oluştur
                    string query = "UPDATE login_ekrani SET sifre = @yeniSifre WHERE kullaniciadi = @kullaniciAdi";

                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        // Parametreleri ekle
                        cmd.Parameters.AddWithValue("@yeniSifre", yeniSifre);
                        cmd.Parameters.AddWithValue("@kullaniciAdi", kullaniciAdi);

                        // SQL komutunu çalıştır
                        int rowsAffected = cmd.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Şifreniz başarıyla değiştirildi.");
                            Form1 form1= new Form1();
                            form1.ShowDialog();
                            this.Hide();
                        }
                        else
                        {
                            MessageBox.Show("Kullanıcı adı bulunamadı.");
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Yeni şifreler aynı olmalıdır.");
            }
        }
    }
}
