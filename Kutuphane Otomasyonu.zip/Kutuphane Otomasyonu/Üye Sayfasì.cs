﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutuphane_Otomasyonu
{
    public partial class Üye_Sayfası : Form
    {
        List<kitap>kitaplarim;
        
        public Üye_Sayfası(List<kitap>kitaplarim)
        {
            InitializeComponent();
            this.kitaplarim = kitaplarim;
            

        }

        private void Üye_Sayfası_Load(object sender, EventArgs e)
        {
            
            foreach(kitap kitap in kitaplarim)
            {
                dataGridView2.Rows.Add(kitap.getkitapid(), kitap.getisim(), kitap.getyazar(), kitap.gettur(), kitap.gettayinevi());
            }
             
            
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            MessageBox.Show("çıkış yapıldı");
            Form1 form1= new Form1();
            form1.ShowDialog();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            kitap hedefkitap = null;
            int secilenid = Convert.ToInt32(textBox6.Text.ToString());
            foreach(kitap kitap in kitaplarim)
            {
                if (secilenid == kitap.getkitapid())
                {
                    hedefkitap = kitap; break;
                }
            }
            dataGridView2.Rows.Clear();
            dataGridView2.Rows.Add(hedefkitap.getkitapid(), hedefkitap.getisim(), hedefkitap.getyazar(), hedefkitap.gettur(), hedefkitap.gettayinevi());

        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Remove(dataGridView2.CurrentRow);
            foreach(kitap hedefkitap in kitaplarim)
            {
                dataGridView2.Rows.Add(hedefkitap.getkitapid(), hedefkitap.getisim(), hedefkitap.getyazar(), hedefkitap.gettur(), hedefkitap.gettayinevi());

            }
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            

        }
    }
}
