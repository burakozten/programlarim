﻿namespace Kutuphane_Otomasyonu
{
    partial class Üye_Sayfası
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.KitapID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.KİTAP_ADI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YAZAR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TÜR = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.YAYINEVİ = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_cikis = new System.Windows.Forms.Button();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 25.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.Location = new System.Drawing.Point(358, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(324, 51);
            this.label1.TabIndex = 0;
            this.label1.Text = "HOŞGELDİNİZ";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.KitapID,
            this.KİTAP_ADI,
            this.YAZAR,
            this.TÜR,
            this.YAYINEVİ});
            this.dataGridView2.Location = new System.Drawing.Point(194, 109);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(675, 405);
            this.dataGridView2.TabIndex = 3;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // KitapID
            // 
            this.KitapID.HeaderText = "KİTAPID";
            this.KitapID.MinimumWidth = 6;
            this.KitapID.Name = "KitapID";
            this.KitapID.Width = 125;
            // 
            // KİTAP_ADI
            // 
            this.KİTAP_ADI.HeaderText = "KİTAP ADI";
            this.KİTAP_ADI.MinimumWidth = 6;
            this.KİTAP_ADI.Name = "KİTAP_ADI";
            this.KİTAP_ADI.Width = 125;
            // 
            // YAZAR
            // 
            this.YAZAR.HeaderText = "YAZAR";
            this.YAZAR.MinimumWidth = 6;
            this.YAZAR.Name = "YAZAR";
            this.YAZAR.Width = 125;
            // 
            // TÜR
            // 
            this.TÜR.HeaderText = "TÜR";
            this.TÜR.MinimumWidth = 6;
            this.TÜR.Name = "TÜR";
            this.TÜR.Width = 125;
            // 
            // YAYINEVİ
            // 
            this.YAYINEVİ.HeaderText = "YAYINEVİ";
            this.YAYINEVİ.MinimumWidth = 6;
            this.YAYINEVİ.Name = "YAYINEVİ";
            this.YAYINEVİ.Width = 125;
            // 
            // btn_cikis
            // 
            this.btn_cikis.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_cikis.ForeColor = System.Drawing.SystemColors.Control;
            this.btn_cikis.Location = new System.Drawing.Point(12, 12);
            this.btn_cikis.Name = "btn_cikis";
            this.btn_cikis.Size = new System.Drawing.Size(138, 23);
            this.btn_cikis.TabIndex = 6;
            this.btn_cikis.Text = "ÇIKIŞ";
            this.btn_cikis.UseVisualStyleBackColor = false;
            this.btn_cikis.Click += new System.EventHandler(this.btn_cikis_Click);
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(720, 80);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(68, 22);
            this.textBox6.TabIndex = 10;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(794, 80);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(75, 23);
            this.button6.TabIndex = 8;
            this.button6.Text = "YENİLE";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(644, 80);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "ARA";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // Üye_Sayfası
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1041, 611);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.btn_cikis);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.label1);
            this.Name = "Üye_Sayfası";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Üye_Sayfası";
            this.Load += new System.EventHandler(this.Üye_Sayfası_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn KitapID;
        private System.Windows.Forms.DataGridViewTextBoxColumn KİTAP_ADI;
        private System.Windows.Forms.DataGridViewTextBoxColumn YAZAR;
        private System.Windows.Forms.DataGridViewTextBoxColumn TÜR;
        private System.Windows.Forms.DataGridViewTextBoxColumn YAYINEVİ;
        private System.Windows.Forms.Button btn_cikis;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button5;
    }
}