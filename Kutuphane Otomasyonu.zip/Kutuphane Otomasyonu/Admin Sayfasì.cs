﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutuphane_Otomasyonu
{
    public partial class Admin_Sayfası : Form
    {
        private List<kisi> liste;
        private Action<List<kisi>> _updateListeCallback;
        private List<kitap> kitaplarim;
        public Admin_Sayfası(List<kisi> liste,List<kitap>kitaplarim ,Action<List<kisi>> updateListeCallback)
        {
            InitializeComponent();
            this.liste = liste;
            this.kitaplarim = kitaplarim;
            this.FormClosed += new FormClosedEventHandler(Admin_Sayfası_FormClosed);
            _updateListeCallback = updateListeCallback;
        }
        private void Admin_Sayfası_FormClosed(object sender, FormClosedEventArgs e)
        {
            // Form kapandığında işlemler
            _updateListeCallback?.Invoke(liste);
        }

        private void Admin_Sayfası_Load(object sender, EventArgs e)
        {
            foreach(kisi kisi in liste)
            {
                dataGridView1.Rows.Add(kisi.getId(), kisi.getIsim(), kisi.getSoyisim(), kisi.getSifre(), kisi.getYetki(),kisi.getTarih(), kisi.getkullaniciadi());
            }
            foreach(kitap kitap in kitaplarim)
            {
                dataGridView2.Rows.Add(kitap.getkitapid(),kitap.getisim(),kitap.getyazar(),kitap.gettur(),kitap.gettayinevi());
            }
        }

        private void btn_ekle_Click(object sender, EventArgs e)
        {
            string id = textBox1.Text.ToString();
            string isim = textBox2.Text.ToString();
            string soyad = textBox3.Text.ToString();
            string sifre = textBox4.Text.ToString();
            string yetki =textBox5.Text.ToString();
            string tarih = maskedTextBox1.Text.ToString();
            string kullanici = textBox7.Text.ToString();
            dataGridView1.Rows.Add(id, isim, soyad, sifre, yetki, tarih, kullanici);

        }

        private void btn_sil_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
            

        }

        private void btn_temizle_Click(object sender, EventArgs e)
        {
            for(int i=0;i<groupBox1.Controls.Count;i++)
            {
                if (groupBox1.Controls[i] is TextBox || groupBox1.Controls[i] is MaskedTextBox) {

                    groupBox1.Controls[i].Text = string.Empty;
                 
                }
            }
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Add(txt_kitapid.Text.ToString(), txt_isim.Text, txt_yazar.Text, txt_tur.Text, txt_yayınevi.Text);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView2.Rows.Remove(dataGridView2.CurrentRow);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            for(int i=0;i<groupBox2.Controls.Count;i++)
            {
                if (groupBox2.Controls[i] is TextBox)
                {
                    groupBox2.Controls[i].Text = string.Empty;
                }
            }
        }

        private void btn_cikis_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ÇIKIŞ YAPILDI");
            Form1 form1 = new Form1();
            form1.ShowDialog();
            this.Hide();
            
        }

        private void button5_Click(object sender, EventArgs e)
        {
            kisi hedefkisi = null;
            //kitap hedefkitap = null;
            int secilenkisiid = Convert.ToInt32(textBox6.Text);
            //int yazilanid = Convert.ToInt32(textBox6.Text);
            
            foreach(kisi kisi in liste)
            {
                if (secilenkisiid == kisi.getId() )
                {
                    hedefkisi=kisi;
                    break;
                }
            }
            dataGridView1.Rows.Clear();
            dataGridView1.Rows.Add(hedefkisi.getId(), hedefkisi.getIsim(), hedefkisi.getSoyisim(), hedefkisi.getSifre(), hedefkisi.getYetki(), hedefkisi.getTarih());
            //foreach(kitap kitap in kitaplarim)
            //{
            //    if (yazilanid == kitap.getkitapid())
            //    {
            //        hedefkitap=kitap;
            //        break;
            //    }
            //    dataGridView2.Rows.Clear();
            //    dataGridView2.Rows.Add(hedefkitap.getkitapid(), hedefkitap.getisim(), hedefkitap.getyazar(), hedefkitap.gettur(), hedefkitap.gettayinevi());
            //}
            
        }

        private void button6_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Remove(dataGridView1.CurrentRow);
            foreach(kisi hedefkisi in liste)
            {
                dataGridView1.Rows.Add(hedefkisi.getId(), hedefkisi.getIsim(), hedefkisi.getSoyisim(), hedefkisi.getSifre(), hedefkisi.getYetki(), hedefkisi.getTarih());
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            textBox1.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            textBox2.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            textBox3.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            textBox4.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            textBox5.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
            maskedTextBox1.Text = dataGridView1.CurrentRow.Cells[5].Value.ToString();
            //textBox7.Text = dataGridView1.CurrentRow.Cells[6].Value.ToString();

        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_kitapid.Text = dataGridView2.CurrentRow.Cells[0].Value.ToString();
            txt_isim.Text = dataGridView2.CurrentRow.Cells[1].Value.ToString();
            txt_yazar.Text = dataGridView2.CurrentRow.Cells[2].Value.ToString();
            txt_tur.Text = dataGridView2.CurrentRow.Cells[3].Value.ToString();
            txt_yayınevi.Text = dataGridView2.CurrentRow.Cells[4].Value.ToString();
        }
    }
}
