﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane_Otomasyonu
{
    public class kitap
    {
        public int kitapid {  get; set; }
        public string kitapismi {  get; set; }
        public string yazar {  get; set; }
        public string tur {  get; set; }
        public string yayinevi {  get; set; }

        public kitap()
        {
            // Varsayılan değerler atama
            kitapid = 0;
            kitapismi = string.Empty;
            yazar = string.Empty;
            tur = string.Empty;
            yayinevi = string.Empty;

        }
    
        public kitap(int kitapid, string kitapismi, string yazar, string tur, string yayinevi)
        {
            this.kitapid = kitapid;
            this.kitapismi = kitapismi;
            this.yazar = yazar;
            this.tur = tur;
            this.yayinevi = yayinevi;
        }
        public int getkitapid()
        {
            return this.kitapid=kitapid;
        }
        public string getisim()
        {
            return this.kitapismi = kitapismi;
        }
        public string getyazar()
        {
            return this.yazar = yazar;
        }
        public string gettur()
        {
            return this.tur = tur;
        }
        public string gettayinevi()
        {
            return this.yayinevi = yayinevi;
        }
    }
}
