﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Kutuphane_Otomasyonu
{
    public class kisi
    {
        public int id {  get; set; }
        public string isim {  get; set; }
        public string soyisim {  get; set; }
        public string sifre {  get; set; }
        public string yetki {  get; set; }
        public DateTime olusturmatarihi { get; set; }
        public string kullaniciadi {  get; set; }

        public kisi()
        {
            // Varsayılan değerler atama
            id = 0;
            isim = string.Empty;
            soyisim = string.Empty;
            sifre = string.Empty;
            yetki = string.Empty;
            kullaniciadi = string.Empty;
            olusturmatarihi = DateTime.Now; // Varsayılan olarak şu anki tarih ve zaman
        }
        public kisi(int id, string isim, string soyisim, string sifre, string yetki, DateTime olusturmatarihi,string kullaniciadi)
        {
            this.id = id;
            this.isim = isim;
            this.soyisim = soyisim;
            this.sifre = sifre;
            this.yetki = yetki;
            this.olusturmatarihi = olusturmatarihi;
            this.kullaniciadi = kullaniciadi;
        }
        public void setId(int id)
        {
            this.id = id;
        }
        public int getId() {
            return id = id;
        }
        public void setIsim(string isim)
        {
            this.isim = isim;
        }
        public string getIsim()
        {
            return isim = isim;
        }
        public void setSoyisim(string soyisim)
        {
            this.soyisim= soyisim;
        }
        public string getSoyisim()
        {
            return soyisim = soyisim;
        }
        public void setkullaniciadi(string kullaniciadi)
        {
            this.kullaniciadi = kullaniciadi;
        }
        public string getkullaniciadi()
        {
            return kullaniciadi= kullaniciadi;
        }
        public void setSifre(string sifre)
        {
            this.sifre= sifre;
        }
        public string getSifre()
        {
            return sifre = sifre;
        }
        public void setTarih(DateTime olusturmatarihi)
        {
            this.olusturmatarihi= olusturmatarihi;
        }
        public DateTime getTarih()
        {
            return olusturmatarihi = olusturmatarihi;
        }
        public void setYetki(string yetki)
        {
            this.yetki= yetki;
        }
        public string getYetki()
        {
            return yetki= yetki;
        }
        public override string ToString()
        {
            return "İsim-Soyisim" + "" + this.isim +""+ this.soyisim;
        }

       

    }
   
}
