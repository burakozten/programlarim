﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kutuphane_Otomasyonu
{
    public partial class Form1 : Form
    {
        List<kisi>liste=new List<kisi>();
        List<kitap>kitaplarim=new List<kitap>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_giris_Click(object sender, EventArgs e)
        {
            string kullaniciadi, sifre = "";
            kullaniciadi = txt_kullanici.Text;
            sifre = txt_sifre.Text;
            bool kontrol = false;
            foreach(kisi kisi in liste)
            {
                if (kullaniciadi.ToLower()==kisi.getkullaniciadi().ToLower()&&sifre.ToLower()==kisi.getSifre().ToLower()&&kisi.getYetki().ToLower()=="admin")
                {
                    //admin sayfası
                    Admin_Sayfası admin_sayfasi = new Admin_Sayfası(liste,kitaplarim,UpdateListe);
                    admin_sayfasi.Show();
                    this.Hide();
                    kontrol= true;
                    break;
                }
                else if (kullaniciadi.ToLower() == kisi.getkullaniciadi().ToLower() && sifre.ToLower() == kisi.getSifre().ToLower() && kisi.getYetki().ToLower() == "üye")
                {
                    Üye_Sayfası uye_sayfasi = new Üye_Sayfası(kitaplarim);
                    uye_sayfasi .Show();
                    this.Hide();
                    kontrol = true;
                    break;
                }
            }
            if (!kontrol)
            {
                MessageBox.Show("hatalı giriş","error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
           

        }
        
        private void btn_temizle_Click(object sender, EventArgs e)
        {
            txt_kullanici.Text=string.Empty;
            txt_sifre.Text=string.Empty;
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            liste.Add(new kisi(1,"BURAK","ÖZTEN","1","admin",DateTime.Now,"burak"));
            liste.Add(new kisi(2, "EMRE", "SERTEL", "343434", "üye", DateTime.Now, "emre"));
            liste.Add(new kisi(3, "MELEK", "ÖZTEN", "5761", "üye", DateTime.Now, "melek"));
            liste.Add(new kisi(4, "BERAT", "PARLAK", "4545", "üye", DateTime.Now, "berat"));
            liste.Add(new kisi(5, "BERRAK", "ÖZTEN", "0000", "üye", DateTime.Now, "berrak"));
            //kitaplar
            kitaplarim.Add(new kitap(1, "Kürk Mantolu Madonna", "SABAHATTİN ALİ", "ROMAN", "YAPIKREDİ YAYINLARI"));
            kitaplarim.Add(new kitap(2, "1984", "GEORGE ORWELL", "DİSTOPYA", "CAN YAYINLARI"));
            kitaplarim.Add(new kitap(3, "Beyaz Zambaklar Ülkesinde", "Grigory Petrov", "İNCELEME", "KORİDOR YAYINLARI"));
            kitaplarim.Add(new kitap(4, "SİMYACI", "Paulo Coelho", "ROMAN", "CAN YAYINLARI"));
        }
        private void UpdateListe(List<kisi> yeniListe)
        {
            liste = yeniListe;
        }
    }
}
